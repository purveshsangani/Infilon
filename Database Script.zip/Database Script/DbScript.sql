USE [master]
GO
/****** Object:  Database [Practical1]    Script Date: 30-04-2022 13:20:34 ******/
CREATE DATABASE [Practical1]
 CONTAINMENT = NONE
 ON  PRIMARY 
( NAME = N'Practical1', FILENAME = N'C:\Program Files\Microsoft SQL Server\MSSQL15.SQLEXPRESS\MSSQL\DATA\Practical1.mdf' , SIZE = 8192KB , MAXSIZE = UNLIMITED, FILEGROWTH = 65536KB )
 LOG ON 
( NAME = N'Practical1_log', FILENAME = N'C:\Program Files\Microsoft SQL Server\MSSQL15.SQLEXPRESS\MSSQL\DATA\Practical1_log.ldf' , SIZE = 8192KB , MAXSIZE = 2048GB , FILEGROWTH = 65536KB )
 WITH CATALOG_COLLATION = DATABASE_DEFAULT
GO
ALTER DATABASE [Practical1] SET COMPATIBILITY_LEVEL = 150
GO
IF (1 = FULLTEXTSERVICEPROPERTY('IsFullTextInstalled'))
begin
EXEC [Practical1].[dbo].[sp_fulltext_database] @action = 'enable'
end
GO
ALTER DATABASE [Practical1] SET ANSI_NULL_DEFAULT OFF 
GO
ALTER DATABASE [Practical1] SET ANSI_NULLS OFF 
GO
ALTER DATABASE [Practical1] SET ANSI_PADDING OFF 
GO
ALTER DATABASE [Practical1] SET ANSI_WARNINGS OFF 
GO
ALTER DATABASE [Practical1] SET ARITHABORT OFF 
GO
ALTER DATABASE [Practical1] SET AUTO_CLOSE OFF 
GO
ALTER DATABASE [Practical1] SET AUTO_SHRINK OFF 
GO
ALTER DATABASE [Practical1] SET AUTO_UPDATE_STATISTICS ON 
GO
ALTER DATABASE [Practical1] SET CURSOR_CLOSE_ON_COMMIT OFF 
GO
ALTER DATABASE [Practical1] SET CURSOR_DEFAULT  GLOBAL 
GO
ALTER DATABASE [Practical1] SET CONCAT_NULL_YIELDS_NULL OFF 
GO
ALTER DATABASE [Practical1] SET NUMERIC_ROUNDABORT OFF 
GO
ALTER DATABASE [Practical1] SET QUOTED_IDENTIFIER OFF 
GO
ALTER DATABASE [Practical1] SET RECURSIVE_TRIGGERS OFF 
GO
ALTER DATABASE [Practical1] SET  DISABLE_BROKER 
GO
ALTER DATABASE [Practical1] SET AUTO_UPDATE_STATISTICS_ASYNC OFF 
GO
ALTER DATABASE [Practical1] SET DATE_CORRELATION_OPTIMIZATION OFF 
GO
ALTER DATABASE [Practical1] SET TRUSTWORTHY OFF 
GO
ALTER DATABASE [Practical1] SET ALLOW_SNAPSHOT_ISOLATION OFF 
GO
ALTER DATABASE [Practical1] SET PARAMETERIZATION SIMPLE 
GO
ALTER DATABASE [Practical1] SET READ_COMMITTED_SNAPSHOT OFF 
GO
ALTER DATABASE [Practical1] SET HONOR_BROKER_PRIORITY OFF 
GO
ALTER DATABASE [Practical1] SET RECOVERY SIMPLE 
GO
ALTER DATABASE [Practical1] SET  MULTI_USER 
GO
ALTER DATABASE [Practical1] SET PAGE_VERIFY CHECKSUM  
GO
ALTER DATABASE [Practical1] SET DB_CHAINING OFF 
GO
ALTER DATABASE [Practical1] SET FILESTREAM( NON_TRANSACTED_ACCESS = OFF ) 
GO
ALTER DATABASE [Practical1] SET TARGET_RECOVERY_TIME = 60 SECONDS 
GO
ALTER DATABASE [Practical1] SET DELAYED_DURABILITY = DISABLED 
GO
ALTER DATABASE [Practical1] SET ACCELERATED_DATABASE_RECOVERY = OFF  
GO
ALTER DATABASE [Practical1] SET QUERY_STORE = OFF
GO
USE [Practical1]
GO
/****** Object:  Table [dbo].[EvenTable]    Script Date: 30-04-2022 13:20:34 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[EvenTable](
	[Id] [int] NOT NULL,
	[UserId] [int] NULL,
	[Title] [nvarchar](150) NULL,
	[Completed] [bit] NULL,
 CONSTRAINT [PK_EvenTable] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[HistoryTable]    Script Date: 30-04-2022 13:20:34 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[HistoryTable](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[ReferenceId] [int] NULL,
	[UserId] [int] NULL,
	[Title] [nvarchar](150) NULL,
	[Completed] [bit] NULL,
	[Action] [nvarchar](50) NULL,
 CONSTRAINT [PK_HistoryTable] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[OddTable]    Script Date: 30-04-2022 13:20:34 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[OddTable](
	[Id] [int] NOT NULL,
	[UserId] [int] NULL,
	[Title] [nvarchar](150) NULL,
	[Completed] [bit] NULL,
 CONSTRAINT [PK_Table_1] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
INSERT [dbo].[EvenTable] ([Id], [UserId], [Title], [Completed]) VALUES (4, 1, N'et porro tempora', 1)
GO
INSERT [dbo].[EvenTable] ([Id], [UserId], [Title], [Completed]) VALUES (6, 1, N'qui ullam ratione quibusdam voluptatem quia omnis', 0)
GO
INSERT [dbo].[EvenTable] ([Id], [UserId], [Title], [Completed]) VALUES (8, 1, N'quo adipisci enim quam ut ab', 1)
GO
INSERT [dbo].[EvenTable] ([Id], [UserId], [Title], [Completed]) VALUES (10, 1, N'illo est ratione doloremque quia maiores aut', 1)
GO
INSERT [dbo].[EvenTable] ([Id], [UserId], [Title], [Completed]) VALUES (12, 1, N'ipsa repellendus fugit nisi', 1)
GO
INSERT [dbo].[EvenTable] ([Id], [UserId], [Title], [Completed]) VALUES (14, 1, N'repellendus sunt dolores architecto voluptatum', 1)
GO
INSERT [dbo].[EvenTable] ([Id], [UserId], [Title], [Completed]) VALUES (16, 1, N'accusamus eos facilis sint et aut voluptatem', 1)
GO
INSERT [dbo].[EvenTable] ([Id], [UserId], [Title], [Completed]) VALUES (18, 1, N'dolorum est consequatur ea mollitia in culpa', 0)
GO
INSERT [dbo].[EvenTable] ([Id], [UserId], [Title], [Completed]) VALUES (20, 1, N'ullam nobis libero sapiente ad optio sint', 1)
GO
INSERT [dbo].[EvenTable] ([Id], [UserId], [Title], [Completed]) VALUES (22, 2, N'distinctio vitae autem nihil ut molestias quo', 1)
GO
INSERT [dbo].[EvenTable] ([Id], [UserId], [Title], [Completed]) VALUES (24, 2, N'adipisci non ad dicta qui amet quaerat doloribus ea', 0)
GO
INSERT [dbo].[EvenTable] ([Id], [UserId], [Title], [Completed]) VALUES (26, 2, N'aliquam aut quasi', 1)
GO
INSERT [dbo].[EvenTable] ([Id], [UserId], [Title], [Completed]) VALUES (28, 2, N'nesciunt totam sit blanditiis sit', 0)
GO
INSERT [dbo].[EvenTable] ([Id], [UserId], [Title], [Completed]) VALUES (30, 2, N'nemo perspiciatis repellat ut dolor libero commodi blanditiis omnis', 1)
GO
INSERT [dbo].[EvenTable] ([Id], [UserId], [Title], [Completed]) VALUES (32, 2, N'earum doloribus ea doloremque quis', 0)
GO
INSERT [dbo].[EvenTable] ([Id], [UserId], [Title], [Completed]) VALUES (34, 2, N'porro aut necessitatibus eaque distinctio', 0)
GO
INSERT [dbo].[EvenTable] ([Id], [UserId], [Title], [Completed]) VALUES (36, 2, N'excepturi deleniti adipisci voluptatem et neque optio illum ad', 1)
GO
INSERT [dbo].[EvenTable] ([Id], [UserId], [Title], [Completed]) VALUES (38, 2, N'totam quia non', 0)
GO
INSERT [dbo].[EvenTable] ([Id], [UserId], [Title], [Completed]) VALUES (40, 2, N'totam atque quo nesciunt', 1)
GO
INSERT [dbo].[EvenTable] ([Id], [UserId], [Title], [Completed]) VALUES (42, 3, N'rerum perferendis error quia ut eveniet', 0)
GO
INSERT [dbo].[EvenTable] ([Id], [UserId], [Title], [Completed]) VALUES (44, 3, N'cum debitis quis accusamus doloremque ipsa natus sapiente omnis', 1)
GO
INSERT [dbo].[EvenTable] ([Id], [UserId], [Title], [Completed]) VALUES (46, 3, N'vel voluptatem repellat nihil placeat corporis', 0)
GO
INSERT [dbo].[EvenTable] ([Id], [UserId], [Title], [Completed]) VALUES (48, 3, N'sit reprehenderit omnis quia', 0)
GO
INSERT [dbo].[EvenTable] ([Id], [UserId], [Title], [Completed]) VALUES (50, 3, N'cupiditate necessitatibus ullam aut quis dolor voluptate', 1)
GO
INSERT [dbo].[EvenTable] ([Id], [UserId], [Title], [Completed]) VALUES (52, 3, N'nesciunt dolorum quis recusandae ad pariatur ratione', 0)
GO
INSERT [dbo].[EvenTable] ([Id], [UserId], [Title], [Completed]) VALUES (54, 3, N'quis et est ut voluptate quam dolor', 1)
GO
INSERT [dbo].[EvenTable] ([Id], [UserId], [Title], [Completed]) VALUES (56, 3, N'deleniti ea temporibus enim', 1)
GO
INSERT [dbo].[EvenTable] ([Id], [UserId], [Title], [Completed]) VALUES (58, 3, N'est dicta totam qui explicabo doloribus qui dignissimos', 0)
GO
INSERT [dbo].[EvenTable] ([Id], [UserId], [Title], [Completed]) VALUES (60, 3, N'et sequi qui architecto ut adipisci', 1)
GO
INSERT [dbo].[EvenTable] ([Id], [UserId], [Title], [Completed]) VALUES (62, 4, N'et placeat et tempore aspernatur sint numquam', 0)
GO
INSERT [dbo].[EvenTable] ([Id], [UserId], [Title], [Completed]) VALUES (64, 4, N'voluptas consequatur qui ut quia magnam nemo esse', 0)
GO
INSERT [dbo].[EvenTable] ([Id], [UserId], [Title], [Completed]) VALUES (66, 4, N'rerum eum molestias autem voluptatum sit optio', 0)
GO
INSERT [dbo].[EvenTable] ([Id], [UserId], [Title], [Completed]) VALUES (68, 4, N'aut id perspiciatis voluptatem iusto', 0)
GO
INSERT [dbo].[EvenTable] ([Id], [UserId], [Title], [Completed]) VALUES (70, 4, N'ut sequi accusantium et mollitia delectus sunt', 0)
GO
INSERT [dbo].[EvenTable] ([Id], [UserId], [Title], [Completed]) VALUES (72, 4, N'praesentium facilis facere quis harum voluptatibus voluptatem eum', 0)
GO
INSERT [dbo].[EvenTable] ([Id], [UserId], [Title], [Completed]) VALUES (74, 4, N'expedita tempore nobis eveniet laborum maiores', 0)
GO
INSERT [dbo].[EvenTable] ([Id], [UserId], [Title], [Completed]) VALUES (76, 4, N'sequi dolorem sed', 1)
GO
INSERT [dbo].[EvenTable] ([Id], [UserId], [Title], [Completed]) VALUES (78, 4, N'reiciendis est magnam amet nemo iste recusandae impedit quaerat', 0)
GO
INSERT [dbo].[EvenTable] ([Id], [UserId], [Title], [Completed]) VALUES (80, 4, N'tempore molestias dolores rerum sequi voluptates ipsum consequatur', 1)
GO
INSERT [dbo].[EvenTable] ([Id], [UserId], [Title], [Completed]) VALUES (82, 5, N'voluptates eum voluptas et dicta', 0)
GO
INSERT [dbo].[EvenTable] ([Id], [UserId], [Title], [Completed]) VALUES (84, 5, N'sunt veritatis ut voluptate', 0)
GO
INSERT [dbo].[EvenTable] ([Id], [UserId], [Title], [Completed]) VALUES (86, 5, N'incidunt ut saepe autem', 1)
GO
INSERT [dbo].[EvenTable] ([Id], [UserId], [Title], [Completed]) VALUES (88, 5, N'vitae aut excepturi laboriosam sint aliquam et et accusantium', 0)
GO
INSERT [dbo].[EvenTable] ([Id], [UserId], [Title], [Completed]) VALUES (90, 5, N'molestiae nisi accusantium tenetur dolorem et', 1)
GO
INSERT [dbo].[EvenTable] ([Id], [UserId], [Title], [Completed]) VALUES (92, 5, N'in omnis laboriosam', 1)
GO
INSERT [dbo].[EvenTable] ([Id], [UserId], [Title], [Completed]) VALUES (94, 5, N'facilis modi saepe mollitia', 0)
GO
INSERT [dbo].[EvenTable] ([Id], [UserId], [Title], [Completed]) VALUES (96, 5, N'nobis suscipit ducimus enim asperiores voluptas', 0)
GO
INSERT [dbo].[EvenTable] ([Id], [UserId], [Title], [Completed]) VALUES (98, 5, N'debitis accusantium ut quo facilis nihil quis sapiente necessitatibus', 1)
GO
INSERT [dbo].[EvenTable] ([Id], [UserId], [Title], [Completed]) VALUES (100, 5, N'excepturi a et neque qui expedita vel voluptate', 0)
GO
INSERT [dbo].[EvenTable] ([Id], [UserId], [Title], [Completed]) VALUES (102, 6, N'sed ab consequatur', 0)
GO
INSERT [dbo].[EvenTable] ([Id], [UserId], [Title], [Completed]) VALUES (104, 6, N'excepturi non laudantium quo', 0)
GO
INSERT [dbo].[EvenTable] ([Id], [UserId], [Title], [Completed]) VALUES (106, 6, N'ad illo quis voluptatem temporibus', 1)
GO
INSERT [dbo].[EvenTable] ([Id], [UserId], [Title], [Completed]) VALUES (108, 6, N'a eos eaque nihil et exercitationem incidunt delectus', 1)
GO
INSERT [dbo].[EvenTable] ([Id], [UserId], [Title], [Completed]) VALUES (110, 6, N'aut aut ea corporis', 1)
GO
INSERT [dbo].[EvenTable] ([Id], [UserId], [Title], [Completed]) VALUES (112, 6, N'consectetur impedit quisquam qui deserunt non rerum consequuntur eius', 0)
GO
INSERT [dbo].[EvenTable] ([Id], [UserId], [Title], [Completed]) VALUES (114, 6, N'cupiditate quos possimus corporis quisquam exercitationem beatae', 0)
GO
INSERT [dbo].[EvenTable] ([Id], [UserId], [Title], [Completed]) VALUES (116, 6, N'ipsa dolores vel facilis ut', 1)
GO
INSERT [dbo].[EvenTable] ([Id], [UserId], [Title], [Completed]) VALUES (118, 6, N'quia modi consequatur vero fugiat', 0)
GO
INSERT [dbo].[EvenTable] ([Id], [UserId], [Title], [Completed]) VALUES (120, 6, N'dolorem laboriosam vel voluptas et aliquam quasi', 0)
GO
INSERT [dbo].[EvenTable] ([Id], [UserId], [Title], [Completed]) VALUES (122, 7, N'provident aut nobis culpa', 1)
GO
INSERT [dbo].[EvenTable] ([Id], [UserId], [Title], [Completed]) VALUES (124, 7, N'qui consectetur id', 0)
GO
INSERT [dbo].[EvenTable] ([Id], [UserId], [Title], [Completed]) VALUES (126, 7, N'ut asperiores perspiciatis veniam ipsum rerum saepe', 1)
GO
INSERT [dbo].[EvenTable] ([Id], [UserId], [Title], [Completed]) VALUES (128, 7, N'eius omnis est qui voluptatem autem', 0)
GO
INSERT [dbo].[EvenTable] ([Id], [UserId], [Title], [Completed]) VALUES (130, 7, N'nulla aliquid eveniet harum laborum libero alias ut unde', 1)
GO
INSERT [dbo].[EvenTable] ([Id], [UserId], [Title], [Completed]) VALUES (132, 7, N'qui molestiae voluptatibus velit iure harum quisquam', 1)
GO
INSERT [dbo].[EvenTable] ([Id], [UserId], [Title], [Completed]) VALUES (134, 7, N'molestiae doloribus et laborum quod ea', 0)
GO
INSERT [dbo].[EvenTable] ([Id], [UserId], [Title], [Completed]) VALUES (136, 7, N'asperiores illo tempora fuga sed ut quasi adipisci', 0)
GO
INSERT [dbo].[EvenTable] ([Id], [UserId], [Title], [Completed]) VALUES (138, 7, N'placeat minima consequatur rem qui ut', 1)
GO
INSERT [dbo].[EvenTable] ([Id], [UserId], [Title], [Completed]) VALUES (140, 7, N'aut consectetur in blanditiis deserunt quia sed laboriosam', 1)
GO
INSERT [dbo].[EvenTable] ([Id], [UserId], [Title], [Completed]) VALUES (142, 8, N'maiores accusantium architecto necessitatibus reiciendis ea aut', 1)
GO
INSERT [dbo].[EvenTable] ([Id], [UserId], [Title], [Completed]) VALUES (144, 8, N'ut eum exercitationem sint', 0)
GO
INSERT [dbo].[EvenTable] ([Id], [UserId], [Title], [Completed]) VALUES (146, 8, N'molestiae suscipit ratione nihil odio libero impedit vero totam', 1)
GO
INSERT [dbo].[EvenTable] ([Id], [UserId], [Title], [Completed]) VALUES (148, 8, N'esse quas et quo quasi exercitationem', 0)
GO
INSERT [dbo].[EvenTable] ([Id], [UserId], [Title], [Completed]) VALUES (150, 8, N'eos amet tempore laudantium fugit a', 0)
GO
INSERT [dbo].[EvenTable] ([Id], [UserId], [Title], [Completed]) VALUES (152, 8, N'odit eligendi recusandae doloremque cumque non', 0)
GO
INSERT [dbo].[EvenTable] ([Id], [UserId], [Title], [Completed]) VALUES (154, 8, N'rerum non ex sapiente', 1)
GO
INSERT [dbo].[EvenTable] ([Id], [UserId], [Title], [Completed]) VALUES (156, 8, N'nam quia quia nulla repellat assumenda quibusdam sit nobis', 1)
GO
INSERT [dbo].[EvenTable] ([Id], [UserId], [Title], [Completed]) VALUES (158, 8, N'debitis vitae delectus et harum accusamus aut deleniti a', 1)
GO
INSERT [dbo].[EvenTable] ([Id], [UserId], [Title], [Completed]) VALUES (160, 8, N'et praesentium aliquam est', 0)
GO
INSERT [dbo].[EvenTable] ([Id], [UserId], [Title], [Completed]) VALUES (162, 9, N'omnis laboriosam molestias animi sunt dolore', 1)
GO
INSERT [dbo].[EvenTable] ([Id], [UserId], [Title], [Completed]) VALUES (164, 9, N'reprehenderit quos aut aut consequatur est sed', 0)
GO
INSERT [dbo].[EvenTable] ([Id], [UserId], [Title], [Completed]) VALUES (166, 9, N'quos quo possimus suscipit minima ut', 0)
GO
INSERT [dbo].[EvenTable] ([Id], [UserId], [Title], [Completed]) VALUES (168, 9, N'recusandae quia qui sunt libero', 0)
GO
INSERT [dbo].[EvenTable] ([Id], [UserId], [Title], [Completed]) VALUES (170, 9, N'quisquam aliquam quia doloribus aut', 0)
GO
INSERT [dbo].[EvenTable] ([Id], [UserId], [Title], [Completed]) VALUES (172, 9, N'et provident amet rerum consectetur et voluptatum', 0)
GO
INSERT [dbo].[EvenTable] ([Id], [UserId], [Title], [Completed]) VALUES (174, 9, N'similique aut quo', 0)
GO
INSERT [dbo].[EvenTable] ([Id], [UserId], [Title], [Completed]) VALUES (176, 9, N'magni soluta corrupti ut maiores rem quidem', 0)
GO
INSERT [dbo].[EvenTable] ([Id], [UserId], [Title], [Completed]) VALUES (178, 9, N'nesciunt itaque commodi tempore', 1)
GO
INSERT [dbo].[EvenTable] ([Id], [UserId], [Title], [Completed]) VALUES (180, 9, N'debitis nisi et dolorem repellat et', 1)
GO
INSERT [dbo].[EvenTable] ([Id], [UserId], [Title], [Completed]) VALUES (182, 10, N'inventore saepe cumque et aut illum enim', 1)
GO
INSERT [dbo].[EvenTable] ([Id], [UserId], [Title], [Completed]) VALUES (184, 10, N'molestias modi perferendis perspiciatis', 0)
GO
INSERT [dbo].[EvenTable] ([Id], [UserId], [Title], [Completed]) VALUES (186, 10, N'explicabo odio est et', 0)
GO
INSERT [dbo].[EvenTable] ([Id], [UserId], [Title], [Completed]) VALUES (188, 10, N'vel non beatae est', 1)
GO
INSERT [dbo].[EvenTable] ([Id], [UserId], [Title], [Completed]) VALUES (190, 10, N'accusamus sint iusto et voluptatem exercitationem', 1)
GO
INSERT [dbo].[EvenTable] ([Id], [UserId], [Title], [Completed]) VALUES (192, 10, N'ut quas possimus exercitationem sint voluptates', 0)
GO
INSERT [dbo].[EvenTable] ([Id], [UserId], [Title], [Completed]) VALUES (194, 10, N'sed ut vero sit molestiae', 0)
GO
INSERT [dbo].[EvenTable] ([Id], [UserId], [Title], [Completed]) VALUES (196, 10, N'consequuntur aut ut fugit similique', 1)
GO
INSERT [dbo].[EvenTable] ([Id], [UserId], [Title], [Completed]) VALUES (198, 10, N'quis eius est sint explicabo', 1)
GO
INSERT [dbo].[EvenTable] ([Id], [UserId], [Title], [Completed]) VALUES (200, 10, N'ipsam aperiam voluptates qui', 0)
GO
SET IDENTITY_INSERT [dbo].[HistoryTable] ON 
GO
INSERT [dbo].[HistoryTable] ([Id], [ReferenceId], [UserId], [Title], [Completed], [Action]) VALUES (1, 3, 1, N'fugiat veniam minus', 0, N'Update')
GO
INSERT [dbo].[HistoryTable] ([Id], [ReferenceId], [UserId], [Title], [Completed], [Action]) VALUES (2, 3, 1, N'fugiat veniam minus', 0, N'Remove')
GO
INSERT [dbo].[HistoryTable] ([Id], [ReferenceId], [UserId], [Title], [Completed], [Action]) VALUES (3, 2, 1, N'quis ut nam facilis et officia qui test', 1, N'Update')
GO
INSERT [dbo].[HistoryTable] ([Id], [ReferenceId], [UserId], [Title], [Completed], [Action]) VALUES (4, 2, 1, N'quis ut nam facilis et officia qui', 0, N'Update')
GO
INSERT [dbo].[HistoryTable] ([Id], [ReferenceId], [UserId], [Title], [Completed], [Action]) VALUES (5, 2, 1, N'quis ut nam facilis et officia qui', 0, N'Remove')
GO
SET IDENTITY_INSERT [dbo].[HistoryTable] OFF
GO
INSERT [dbo].[OddTable] ([Id], [UserId], [Title], [Completed]) VALUES (5, 1, N'laboriosam mollitia et enim quasi adipisci quia provident illum', 0)
GO
INSERT [dbo].[OddTable] ([Id], [UserId], [Title], [Completed]) VALUES (7, 1, N'illo expedita consequatur quia in', 0)
GO
INSERT [dbo].[OddTable] ([Id], [UserId], [Title], [Completed]) VALUES (9, 1, N'molestiae perspiciatis ipsa', 0)
GO
INSERT [dbo].[OddTable] ([Id], [UserId], [Title], [Completed]) VALUES (11, 1, N'vero rerum temporibus dolor', 1)
GO
INSERT [dbo].[OddTable] ([Id], [UserId], [Title], [Completed]) VALUES (13, 1, N'et doloremque nulla', 0)
GO
INSERT [dbo].[OddTable] ([Id], [UserId], [Title], [Completed]) VALUES (15, 1, N'ab voluptatum amet voluptas', 1)
GO
INSERT [dbo].[OddTable] ([Id], [UserId], [Title], [Completed]) VALUES (17, 1, N'quo laboriosam deleniti aut qui', 1)
GO
INSERT [dbo].[OddTable] ([Id], [UserId], [Title], [Completed]) VALUES (19, 1, N'molestiae ipsa aut voluptatibus pariatur dolor nihil', 1)
GO
INSERT [dbo].[OddTable] ([Id], [UserId], [Title], [Completed]) VALUES (21, 2, N'suscipit repellat esse quibusdam voluptatem incidunt', 0)
GO
INSERT [dbo].[OddTable] ([Id], [UserId], [Title], [Completed]) VALUES (23, 2, N'et itaque necessitatibus maxime molestiae qui quas velit', 0)
GO
INSERT [dbo].[OddTable] ([Id], [UserId], [Title], [Completed]) VALUES (25, 2, N'voluptas quo tenetur perspiciatis explicabo natus', 1)
GO
INSERT [dbo].[OddTable] ([Id], [UserId], [Title], [Completed]) VALUES (27, 2, N'veritatis pariatur delectus', 1)
GO
INSERT [dbo].[OddTable] ([Id], [UserId], [Title], [Completed]) VALUES (29, 2, N'laborum aut in quam', 0)
GO
INSERT [dbo].[OddTable] ([Id], [UserId], [Title], [Completed]) VALUES (31, 2, N'repudiandae totam in est sint facere fuga', 0)
GO
INSERT [dbo].[OddTable] ([Id], [UserId], [Title], [Completed]) VALUES (33, 2, N'sint sit aut vero', 0)
GO
INSERT [dbo].[OddTable] ([Id], [UserId], [Title], [Completed]) VALUES (35, 2, N'repellendus veritatis molestias dicta incidunt', 1)
GO
INSERT [dbo].[OddTable] ([Id], [UserId], [Title], [Completed]) VALUES (37, 2, N'sunt cum tempora', 0)
GO
INSERT [dbo].[OddTable] ([Id], [UserId], [Title], [Completed]) VALUES (39, 2, N'doloremque quibusdam asperiores libero corrupti illum qui omnis', 0)
GO
INSERT [dbo].[OddTable] ([Id], [UserId], [Title], [Completed]) VALUES (41, 3, N'aliquid amet impedit consequatur aspernatur placeat eaque fugiat suscipit', 0)
GO
INSERT [dbo].[OddTable] ([Id], [UserId], [Title], [Completed]) VALUES (43, 3, N'tempore ut sint quis recusandae', 1)
GO
INSERT [dbo].[OddTable] ([Id], [UserId], [Title], [Completed]) VALUES (45, 3, N'velit soluta adipisci molestias reiciendis harum', 0)
GO
INSERT [dbo].[OddTable] ([Id], [UserId], [Title], [Completed]) VALUES (47, 3, N'nam qui rerum fugiat accusamus', 0)
GO
INSERT [dbo].[OddTable] ([Id], [UserId], [Title], [Completed]) VALUES (49, 3, N'ut necessitatibus aut maiores debitis officia blanditiis velit et', 0)
GO
INSERT [dbo].[OddTable] ([Id], [UserId], [Title], [Completed]) VALUES (51, 3, N'distinctio exercitationem ab doloribus', 0)
GO
INSERT [dbo].[OddTable] ([Id], [UserId], [Title], [Completed]) VALUES (53, 3, N'qui labore est occaecati recusandae aliquid quam', 0)
GO
INSERT [dbo].[OddTable] ([Id], [UserId], [Title], [Completed]) VALUES (55, 3, N'voluptatum omnis minima qui occaecati provident nulla voluptatem ratione', 1)
GO
INSERT [dbo].[OddTable] ([Id], [UserId], [Title], [Completed]) VALUES (57, 3, N'pariatur et magnam ea doloribus similique voluptatem rerum quia', 0)
GO
INSERT [dbo].[OddTable] ([Id], [UserId], [Title], [Completed]) VALUES (59, 3, N'perspiciatis velit id laborum placeat iusto et aliquam odio', 0)
GO
INSERT [dbo].[OddTable] ([Id], [UserId], [Title], [Completed]) VALUES (61, 4, N'odit optio omnis qui sunt', 1)
GO
INSERT [dbo].[OddTable] ([Id], [UserId], [Title], [Completed]) VALUES (63, 4, N'doloremque aut dolores quidem fuga qui nulla', 1)
GO
INSERT [dbo].[OddTable] ([Id], [UserId], [Title], [Completed]) VALUES (65, 4, N'fugiat pariatur ratione ut asperiores necessitatibus magni', 0)
GO
INSERT [dbo].[OddTable] ([Id], [UserId], [Title], [Completed]) VALUES (67, 4, N'quia voluptatibus voluptatem quos similique maiores repellat', 0)
GO
INSERT [dbo].[OddTable] ([Id], [UserId], [Title], [Completed]) VALUES (69, 4, N'doloribus sint dolorum ab adipisci itaque dignissimos aliquam suscipit', 0)
GO
INSERT [dbo].[OddTable] ([Id], [UserId], [Title], [Completed]) VALUES (71, 4, N'aut velit saepe ullam', 0)
GO
INSERT [dbo].[OddTable] ([Id], [UserId], [Title], [Completed]) VALUES (73, 4, N'sint amet quia totam corporis qui exercitationem commodi', 1)
GO
INSERT [dbo].[OddTable] ([Id], [UserId], [Title], [Completed]) VALUES (75, 4, N'occaecati adipisci est possimus totam', 0)
GO
INSERT [dbo].[OddTable] ([Id], [UserId], [Title], [Completed]) VALUES (77, 4, N'maiores aut nesciunt delectus exercitationem vel assumenda eligendi at', 0)
GO
INSERT [dbo].[OddTable] ([Id], [UserId], [Title], [Completed]) VALUES (79, 4, N'eum ipsa maxime ut', 1)
GO
INSERT [dbo].[OddTable] ([Id], [UserId], [Title], [Completed]) VALUES (81, 5, N'suscipit qui totam', 1)
GO
INSERT [dbo].[OddTable] ([Id], [UserId], [Title], [Completed]) VALUES (83, 5, N'quidem at rerum quis ex aut sit quam', 1)
GO
INSERT [dbo].[OddTable] ([Id], [UserId], [Title], [Completed]) VALUES (85, 5, N'et quia ad iste a', 1)
GO
INSERT [dbo].[OddTable] ([Id], [UserId], [Title], [Completed]) VALUES (87, 5, N'laudantium quae eligendi consequatur quia et vero autem', 1)
GO
INSERT [dbo].[OddTable] ([Id], [UserId], [Title], [Completed]) VALUES (89, 5, N'sequi ut omnis et', 1)
GO
INSERT [dbo].[OddTable] ([Id], [UserId], [Title], [Completed]) VALUES (91, 5, N'nulla quis consequatur saepe qui id expedita', 1)
GO
INSERT [dbo].[OddTable] ([Id], [UserId], [Title], [Completed]) VALUES (93, 5, N'odio iure consequatur molestiae quibusdam necessitatibus quia sint', 1)
GO
INSERT [dbo].[OddTable] ([Id], [UserId], [Title], [Completed]) VALUES (95, 5, N'vel nihil et molestiae iusto assumenda nemo quo ut', 1)
GO
INSERT [dbo].[OddTable] ([Id], [UserId], [Title], [Completed]) VALUES (97, 5, N'dolorum laboriosam eos qui iure aliquam', 0)
GO
INSERT [dbo].[OddTable] ([Id], [UserId], [Title], [Completed]) VALUES (99, 5, N'neque voluptates ratione', 0)
GO
INSERT [dbo].[OddTable] ([Id], [UserId], [Title], [Completed]) VALUES (101, 6, N'explicabo enim cumque porro aperiam occaecati minima', 0)
GO
INSERT [dbo].[OddTable] ([Id], [UserId], [Title], [Completed]) VALUES (103, 6, N'non sunt delectus illo nulla tenetur enim omnis', 0)
GO
INSERT [dbo].[OddTable] ([Id], [UserId], [Title], [Completed]) VALUES (105, 6, N'totam quia dolorem et illum repellat voluptas optio', 1)
GO
INSERT [dbo].[OddTable] ([Id], [UserId], [Title], [Completed]) VALUES (107, 6, N'praesentium facilis omnis laudantium fugit ad iusto nihil nesciunt', 0)
GO
INSERT [dbo].[OddTable] ([Id], [UserId], [Title], [Completed]) VALUES (109, 6, N'autem temporibus harum quisquam in culpa', 1)
GO
INSERT [dbo].[OddTable] ([Id], [UserId], [Title], [Completed]) VALUES (111, 6, N'magni accusantium labore et id quis provident', 0)
GO
INSERT [dbo].[OddTable] ([Id], [UserId], [Title], [Completed]) VALUES (113, 6, N'quia atque aliquam sunt impedit voluptatum rerum assumenda nisi', 0)
GO
INSERT [dbo].[OddTable] ([Id], [UserId], [Title], [Completed]) VALUES (115, 6, N'sed et ea eum', 0)
GO
INSERT [dbo].[OddTable] ([Id], [UserId], [Title], [Completed]) VALUES (117, 6, N'sequi quae est et qui qui eveniet asperiores', 0)
GO
INSERT [dbo].[OddTable] ([Id], [UserId], [Title], [Completed]) VALUES (119, 6, N'corporis ducimus ea perspiciatis iste', 0)
GO
INSERT [dbo].[OddTable] ([Id], [UserId], [Title], [Completed]) VALUES (121, 7, N'inventore aut nihil minima laudantium hic qui omnis', 1)
GO
INSERT [dbo].[OddTable] ([Id], [UserId], [Title], [Completed]) VALUES (123, 7, N'esse et quis iste est earum aut impedit', 0)
GO
INSERT [dbo].[OddTable] ([Id], [UserId], [Title], [Completed]) VALUES (125, 7, N'aut quasi autem iste tempore illum possimus', 0)
GO
INSERT [dbo].[OddTable] ([Id], [UserId], [Title], [Completed]) VALUES (127, 7, N'voluptatem libero consectetur rerum ut', 1)
GO
INSERT [dbo].[OddTable] ([Id], [UserId], [Title], [Completed]) VALUES (129, 7, N'rerum culpa quis harum', 0)
GO
INSERT [dbo].[OddTable] ([Id], [UserId], [Title], [Completed]) VALUES (131, 7, N'qui ea incidunt quis', 0)
GO
INSERT [dbo].[OddTable] ([Id], [UserId], [Title], [Completed]) VALUES (133, 7, N'et labore eos enim rerum consequatur sunt', 1)
GO
INSERT [dbo].[OddTable] ([Id], [UserId], [Title], [Completed]) VALUES (135, 7, N'facere ipsa nam eum voluptates reiciendis vero qui', 0)
GO
INSERT [dbo].[OddTable] ([Id], [UserId], [Title], [Completed]) VALUES (137, 7, N'qui sit non', 0)
GO
INSERT [dbo].[OddTable] ([Id], [UserId], [Title], [Completed]) VALUES (139, 7, N'consequatur doloribus id possimus voluptas a voluptatem', 0)
GO
INSERT [dbo].[OddTable] ([Id], [UserId], [Title], [Completed]) VALUES (141, 8, N'explicabo consectetur debitis voluptates quas quae culpa rerum non', 1)
GO
INSERT [dbo].[OddTable] ([Id], [UserId], [Title], [Completed]) VALUES (143, 8, N'eum non recusandae cupiditate animi', 0)
GO
INSERT [dbo].[OddTable] ([Id], [UserId], [Title], [Completed]) VALUES (145, 8, N'beatae qui ullam incidunt voluptatem non nisi aliquam', 0)
GO
INSERT [dbo].[OddTable] ([Id], [UserId], [Title], [Completed]) VALUES (147, 8, N'eum itaque quod reprehenderit et facilis dolor autem ut', 1)
GO
INSERT [dbo].[OddTable] ([Id], [UserId], [Title], [Completed]) VALUES (149, 8, N'animi voluptas quod perferendis est', 0)
GO
INSERT [dbo].[OddTable] ([Id], [UserId], [Title], [Completed]) VALUES (151, 8, N'accusamus adipisci dicta qui quo ea explicabo sed vero', 1)
GO
INSERT [dbo].[OddTable] ([Id], [UserId], [Title], [Completed]) VALUES (153, 8, N'ea aperiam consequatur qui repellat eos', 0)
GO
INSERT [dbo].[OddTable] ([Id], [UserId], [Title], [Completed]) VALUES (155, 8, N'voluptatem nobis consequatur et assumenda magnam', 1)
GO
INSERT [dbo].[OddTable] ([Id], [UserId], [Title], [Completed]) VALUES (157, 8, N'dolorem veniam quisquam deserunt repellendus', 1)
GO
INSERT [dbo].[OddTable] ([Id], [UserId], [Title], [Completed]) VALUES (159, 8, N'debitis adipisci quibusdam aliquam sed dolore ea praesentium nobis', 1)
GO
INSERT [dbo].[OddTable] ([Id], [UserId], [Title], [Completed]) VALUES (161, 9, N'ex hic consequuntur earum omnis alias ut occaecati culpa', 1)
GO
INSERT [dbo].[OddTable] ([Id], [UserId], [Title], [Completed]) VALUES (163, 9, N'natus corrupti maxime laudantium et voluptatem laboriosam odit', 0)
GO
INSERT [dbo].[OddTable] ([Id], [UserId], [Title], [Completed]) VALUES (165, 9, N'fugiat perferendis sed aut quidem', 0)
GO
INSERT [dbo].[OddTable] ([Id], [UserId], [Title], [Completed]) VALUES (167, 9, N'et quis minus quo a asperiores molestiae', 0)
GO
INSERT [dbo].[OddTable] ([Id], [UserId], [Title], [Completed]) VALUES (169, 9, N'ea odio perferendis officiis', 1)
GO
INSERT [dbo].[OddTable] ([Id], [UserId], [Title], [Completed]) VALUES (171, 9, N'fugiat aut voluptatibus corrupti deleniti velit iste odio', 1)
GO
INSERT [dbo].[OddTable] ([Id], [UserId], [Title], [Completed]) VALUES (173, 9, N'harum ad aperiam quis', 0)
GO
INSERT [dbo].[OddTable] ([Id], [UserId], [Title], [Completed]) VALUES (175, 9, N'laudantium eius officia perferendis provident perspiciatis asperiores', 1)
GO
INSERT [dbo].[OddTable] ([Id], [UserId], [Title], [Completed]) VALUES (177, 9, N'et placeat temporibus voluptas est tempora quos quibusdam', 0)
GO
INSERT [dbo].[OddTable] ([Id], [UserId], [Title], [Completed]) VALUES (179, 9, N'omnis consequuntur cupiditate impedit itaque ipsam quo', 1)
GO
INSERT [dbo].[OddTable] ([Id], [UserId], [Title], [Completed]) VALUES (181, 10, N'ut cupiditate sequi aliquam fuga maiores', 0)
GO
INSERT [dbo].[OddTable] ([Id], [UserId], [Title], [Completed]) VALUES (183, 10, N'omnis nulla eum aliquam distinctio', 1)
GO
INSERT [dbo].[OddTable] ([Id], [UserId], [Title], [Completed]) VALUES (185, 10, N'voluptates dignissimos sed doloribus animi quaerat aut', 0)
GO
INSERT [dbo].[OddTable] ([Id], [UserId], [Title], [Completed]) VALUES (187, 10, N'consequuntur animi possimus', 0)
GO
INSERT [dbo].[OddTable] ([Id], [UserId], [Title], [Completed]) VALUES (189, 10, N'culpa eius et voluptatem et', 1)
GO
INSERT [dbo].[OddTable] ([Id], [UserId], [Title], [Completed]) VALUES (191, 10, N'temporibus atque distinctio omnis eius impedit tempore molestias pariatur', 1)
GO
INSERT [dbo].[OddTable] ([Id], [UserId], [Title], [Completed]) VALUES (193, 10, N'rerum debitis voluptatem qui eveniet tempora distinctio a', 1)
GO
INSERT [dbo].[OddTable] ([Id], [UserId], [Title], [Completed]) VALUES (195, 10, N'rerum ex veniam mollitia voluptatibus pariatur', 1)
GO
INSERT [dbo].[OddTable] ([Id], [UserId], [Title], [Completed]) VALUES (197, 10, N'dignissimos quo nobis earum saepe', 1)
GO
INSERT [dbo].[OddTable] ([Id], [UserId], [Title], [Completed]) VALUES (199, 10, N'numquam repellendus a magnam', 1)
GO
USE [master]
GO
ALTER DATABASE [Practical1] SET  READ_WRITE 
GO
